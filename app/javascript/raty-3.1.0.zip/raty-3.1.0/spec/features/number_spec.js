describe('#number', function() {
  beforeEach(function() {
    $.raty.path = '../lib/images';

    this.el = Helper.create('#el');
  });

  afterEach(function() {
    Helper.clear();
  });

  it ('changes the number of stars', function() {
    // given

    // when
    this.el.raty({ number: 1 });

    // then
    expect(this.el.children('img').length).toEqual(1);
  });

  it ('accepts number as string', function() {
    // given

    // when
    this.el.raty({ number: '1' });

    // then
    expect(this.el.children('img').length).toEqual(1);
  });

  it ('accepts callback', function() {
    // given

    // when
    this.el.raty({ number: function() { return 1; } });

    // then
    expect(this.el.data('raty').opt.number).toEqual(1);
  });

  it ('accepts data attribute', function() {
    // given
    var el = Helper._append('div', { 'data-number': 3 });

    // when
    el.raty();

    // then
    expect(el.data('raty').opt.number).toEqual(3);
  });
});
